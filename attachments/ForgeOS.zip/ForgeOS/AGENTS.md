# AGENTS.md — ForgeOS (Real-World Mode)

> Play mode is over. Every agent session is judged only by real-world economic progress.

## Project Identity

ForgeOS is an autonomous intelligence + execution system whose only legitimate output is **real economic results**.

Core loop: Signals → Patterns → Beliefs → Opportunities → Decisions → Execution → Money Engine

## Non-Negotiable Standard

A piece of work is only complete if it produces at least one of:

1. A real opportunity with evidence of problem + customer + willingness-to-pay
2. A concrete real-world action a human can execute within 24 hours
3. Verified or high-confidence monetary evidence
4. A hard negative result that kills a false path with evidence

Pretty dashboards, clean logs, and theoretical improvements that do not move the above are secondary.

## Hard Rules

- Signal quality is sacred. Never lower the floor.
- Money Engine stays evidence-based. No invented expected value.
- Prefer driving the existing 5 high-quality seeded signals to a real opportunity over collecting more noise.
- Fix cycle reliability only so we can force real results, not for its own sake.
- UI work is frozen unless it directly helps a human act on a real opportunity.
- Default `AI_PROVIDER=mock` unless the human explicitly wants live model calls.

## Current Priority (see docs/CURRENT_FOCUS.md)

1. Stabilize the forced daily cycle (disk I/O / transaction errors)
2. Push seeded signals through to scored opportunities
3. Surface one concrete, real-world next action
4. Log the result and decide kill or execute

## Workflow (mandatory)

Intent → Plan (wait for approval) → Implement → Verify → Memory

Always start a session by reading:
- AGENTS.md
- docs/CURRENT_FOCUS.md
- docs/SESSION_START.md

## Key Commands

```bash
cd backend
python -m scripts.seed_signals
python -m scripts.run_daily_cycle --times 1
```

## Phase Status

- [x] Premium UI (done, now frozen)
- [x] 5 real seeded signals
- [ ] Reliable forced cycle
- [ ] One real scored opportunity with actionable next step
- [ ] One real-world action taken or ready to take

Until the last two boxes are checked, we are still in play mode. That is no longer acceptable.
