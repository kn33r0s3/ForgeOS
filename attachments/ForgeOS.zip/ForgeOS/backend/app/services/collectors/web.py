"""
Web collector — fetches a single web page and extracts its visible
text, using only stdlib (urllib + html.parser). No requests or
BeautifulSoup dependency.

There is no free general-purpose web *search* API without a key, so
unlike the other collectors, `query` here is treated as a direct URL
to fetch rather than a search term. A future version could add a
proper search layer (e.g. a self-hosted SearXNG instance) in front of
this without changing the SourceCollector interface.
"""

import urllib.request
from html.parser import HTMLParser

from app.services.collectors.base import SourceCollector

USER_AGENT = "ForgeOS/0.1 (research collector)"
TIMEOUT_SECONDS = 10
SKIP_TAGS = {"script", "style", "noscript"}


class _VisibleTextExtractor(HTMLParser):
    def __init__(self):
        super().__init__()
        self._chunks: list[str] = []
        self._skip_depth = 0

    def handle_starttag(self, tag, attrs):
        if tag in SKIP_TAGS:
            self._skip_depth += 1

    def handle_endtag(self, tag):
        if tag in SKIP_TAGS and self._skip_depth > 0:
            self._skip_depth -= 1

    def handle_data(self, data):
        if self._skip_depth == 0:
            text = data.strip()
            if text:
                self._chunks.append(text)

    def text(self) -> str:
        return " ".join(self._chunks)


class WebCollector(SourceCollector):
    source_name = "web"
    source_type = "general"

    def collect(self, query: str) -> list[dict]:
        request = urllib.request.Request(query, headers={"User-Agent": USER_AGENT})

        try:
            with urllib.request.urlopen(request, timeout=TIMEOUT_SECONDS) as response:
                html = response.read().decode("utf-8", errors="ignore")
        except Exception as exc:
            raise RuntimeError(f"Web collector failed for url '{query}': {exc}") from exc

        parser = _VisibleTextExtractor()
        parser.feed(html)
        text = parser.text()
        if not text:
            return []

        return [{"content": text[:1500], "timestamp": None, "metadata": {"url": query}}]
