"""Shared fixtures — use in-memory SQLite to avoid sandbox disk I/O issues."""
import os
import sys
import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

# Must set before importing app.database
os.environ.setdefault("DATABASE_URL", "sqlite:///:memory:")
os.environ.setdefault("AI_PROVIDER", "mock")


@pytest.fixture
def db():
    """Fresh in-memory DB per test with all tables."""
    from sqlalchemy import create_engine
    from sqlalchemy.orm import sessionmaker
    from app.database import Base
    from app import models  # noqa: F401 — register models
    from app.services import source_manager

    engine = create_engine("sqlite:///:memory:", connect_args={"check_same_thread": False})
    Base.metadata.create_all(bind=engine)
    Session = sessionmaker(bind=engine)
    session = Session()
    source_manager.seed_default_sources(session)
    yield session
    session.close()
    engine.dispose()
