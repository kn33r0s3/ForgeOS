import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import ServicePage from "./pages/ServicePage";
import ServicesPage from "./pages/ServicesPage";
import WorkPage from "./pages/WorkPage";
import InfoPage from "./pages/InfoPage";
import RequestPage from "./pages/RequestPage";
import BusinessesPage from "./pages/BusinessesPage";
import AreaPage from "./pages/AreaPage";
import ToolsPage from "./pages/ToolsPage";
import CompanyFeeToolPage from "./pages/CompanyFeeToolPage";
import PanVatGuidePage from "./pages/PanVatGuidePage";
import InsightsPage from "./pages/InsightsPage";
import GroupPage from "./pages/GroupPage";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/services" component={ServicesPage} />
      <Route path="/group" component={GroupPage} />
      <Route path="/group/businesses" component={BusinessesPage} />
      <Route path="/technology" component={() => <AreaPage name="Technology" />} />
      <Route path="/operations" component={() => <AreaPage name="Operations" />} />
      <Route path="/ventures" component={() => <AreaPage name="Ventures" />} />
      <Route path="/services/software" component={() => <ServicePage slug="software" />} />
      <Route path="/services/automation" component={() => <ServicePage slug="automation" />} />
      <Route path="/services/operations" component={() => <ServicePage slug="operations" />} />
      <Route path="/services/internal-tools" component={() => <ServicePage slug="internal-tools" />} />
      <Route path="/services/workflows" component={() => <ServicePage slug="workflows" />} />
      <Route path="/services/support" component={() => <ServicePage slug="support" />} />
      <Route path="/tools" component={ToolsPage} />
      <Route path="/tools/company-registration-fee" component={CompanyFeeToolPage} />
      <Route path="/tools/pan-vat-guide" component={PanVatGuidePage} />
      <Route path="/insights" component={InsightsPage} />
      <Route path="/about" component={() => <InfoPage kind="about" />} />
      <Route path="/work" component={WorkPage} />
      <Route path="/process" component={() => <InfoPage kind="process" />} />
      <Route path="/contact" component={() => <InfoPage kind="contact" />} />
      <Route path="/request" component={RequestPage} />
      <Route path="/request-a-project" component={RequestPage} />
      <Route path="/404" component={NotFound} />
      <Route component={NotFound} />
    </Switch>
  );
}

export default function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="light">
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}
