import { ArrowUpRight } from "lucide-react";
import { Link } from "wouter";

export default function CTASection() {
  return <section className="cta-section"><div className="container cta-inner"><div><p className="eyebrow">A sensible next step</p><h2>Have a hard-to-explain<br /><span>problem?</span></h2><p className="muted">Start with the situation. We’ll help work out what the system should be.</p></div><Link href="/request-a-project" className="primary-button light-button">Talk to Sanip Ops <ArrowUpRight size={17} /></Link></div></section>;
}
