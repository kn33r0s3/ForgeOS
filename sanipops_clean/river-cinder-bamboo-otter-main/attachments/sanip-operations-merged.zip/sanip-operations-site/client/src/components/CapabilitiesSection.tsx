import { ArrowUpRight } from "lucide-react";
import { groupAreas } from "./groupData";

export default function CapabilitiesSection() {
  return <section className="capabilities-section"><div className="container capabilities-grid"><div><p className="eyebrow">The group map</p><h2>Many directions.<br /><span>One operating core.</span></h2><p className="muted systems-copy">Sanip Ops is being shaped as a parent platform. These are strategic directions for the group, not a list of existing subsidiaries or operating companies.</p><div className="capability-note"><span className="note-mark">HONEST STATUS</span><p><strong>Future structure</strong><br />Each area is a direction for development. Current operations are not overstated.</p></div></div><div className="capability-list">{groupAreas.map((area, index) => <div className="capability-row" key={area.name}><span>{String(index + 1).padStart(2, "0")}</span><strong>{area.name}</strong><small className="capability-kind">{area.status}</small><ArrowUpRight size={16} /></div>)}</div></div></section>;
}
