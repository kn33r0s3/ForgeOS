import { Link } from "wouter";

export default function Footer() {
  return <footer className="footer"><div className="container footer-grid"><div><div className="brand footer-brand"><span className="brand-mark">S</span><span>Sanip <em>Ops</em></span></div><p className="footer-note">A quiet, technically strong operations and infrastructure company building useful digital systems from Nepal.</p></div><div><p className="eyebrow">Explore</p><Link href="/services">Services</Link><Link href="/process">How we work</Link><Link href="/work">Capabilities</Link></div><div><p className="eyebrow">Connect</p><Link href="/request-a-project">Start a project</Link><a href="mailto:hello@sanipoperations.com.np">hello@sanipoperations.com.np</a><a href="https://sanipoperations.com.np" target="_blank" rel="noreferrer">sanipoperations.com.np</a></div></div><div className="container footer-bottom"><span>© {new Date().getFullYear()} Sanip Operations</span><span>Nepal · Remote-ready</span></div></footer>;
}
