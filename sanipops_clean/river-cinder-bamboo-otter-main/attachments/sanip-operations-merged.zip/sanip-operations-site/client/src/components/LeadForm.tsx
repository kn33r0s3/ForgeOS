import { FormEvent, useState } from "react";
import { Check } from "lucide-react";
import { toast } from "sonner";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { trpc } from "@/lib/trpc";

/**
 * Lead intake form shared by the utility tools.
 *
 * Merged from nepal_utility_portal: the original posted to a separate FastAPI
 * lead server with a localStorage fallback. Here it goes through the single
 * Sanip Ops tRPC backend (leads.create) with server-side Nepal-mobile
 * validation and rate limiting. Collected fields are deliberately minimal:
 * name, phone, district, category. Never OTPs, PINs, citizenship numbers, or
 * payment credentials.
 */
export default function LeadForm({ tool, contextNote }: { tool: string; contextNote: string }) {
  const [submitted, setSubmitted] = useState(false);
  const mutation = trpc.leads.create.useMutation({
    onSuccess: () => {
      setSubmitted(true);
      toast.success("Inquiry received.");
    },
    onError: (error) => toast.error(error.message || "Please check the form and try again."),
  });

  const submit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const values = Object.fromEntries(new FormData(event.currentTarget).entries());
    if (String(values.hp_field || "")) return;
    if (!values.name || !values.phone) {
      toast.error("Please provide your name and a Nepal mobile number.");
      return;
    }
    mutation.mutate({
      name: String(values.name),
      phone: String(values.phone),
      district: String(values.district || ""),
      category: "tool-inquiry",
      tool,
      note: String(values.note || ""),
    });
  };

  if (submitted) {
    return (
      <div className="lead-success">
        <div className="success-icon"><Check /></div>
        <h3>Inquiry received.</h3>
        <p className="muted">If a registered local firm partners with us to follow up, your inquiry may be shared with them — nothing else happens with it.</p>
      </div>
    );
  }

  return (
    <form className="request-form lead-form" onSubmit={submit} noValidate>
      <div aria-hidden="true" className="honeypot">
        <label htmlFor={`hp_${tool}`}>Leave this field empty</label>
        <input id={`hp_${tool}`} name="hp_field" tabIndex={-1} autoComplete="off" />
      </div>
      <div className="form-row">
        <div>
          <Label htmlFor={`${tool}_name`}>Name <span>*</span></Label>
          <Input id={`${tool}_name`} name="name" placeholder="Your name" required />
        </div>
        <div>
          <Label htmlFor={`${tool}_phone`}>Nepal mobile <span>*</span></Label>
          <Input id={`${tool}_phone`} name="phone" type="tel" inputMode="tel" placeholder="98XXXXXXXX" required />
        </div>
      </div>
      <div>
        <Label htmlFor={`${tool}_district`}>District</Label>
        <Input id={`${tool}_district`} name="district" placeholder="e.g. Kathmandu (optional)" />
      </div>
      <div>
        <Label htmlFor={`${tool}_note`}>What do you need help with?</Label>
        <Textarea id={`${tool}_note`} name="note" placeholder={contextNote} />
      </div>
      <button type="submit" className="primary-button" disabled={mutation.isPending}>
        {mutation.isPending ? "Sending…" : "Request a follow-up"}
      </button>
      <p className="form-note">Optional. Stores only name, phone, district, and note. No payment details, IDs, or credentials.</p>
    </form>
  );
}
