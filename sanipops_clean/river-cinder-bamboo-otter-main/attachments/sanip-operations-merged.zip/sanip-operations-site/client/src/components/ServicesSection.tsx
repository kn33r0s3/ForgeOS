import { ArrowUpRight } from "lucide-react";
import { Link } from "wouter";
import { services } from "./homeData";

export default function ServicesSection() {
  return <section className="services-section" id="services"><div className="container"><div className="section-heading"><div><p className="eyebrow">What we do</p><h2>Built around the<br /><span>actual operation.</span></h2></div><p className="muted heading-note">Focused services for teams that need a capable technical partner without unnecessary complexity.</p></div><div className="service-grid">{services.map((service) => <article className="service-card" key={service.number}><div className="card-meta"><span>{service.number}</span><span>Sanip / Ops</span></div><h3>{service.title}</h3><p className="muted">{service.body}</p><Link href="/request-a-project" className="card-link">Talk through this <ArrowUpRight size={15} /></Link></article>)}</div></div></section>;
}
