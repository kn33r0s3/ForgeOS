import { ArrowUpRight, Menu, X } from "lucide-react";
import { type ReactNode, useEffect, useState } from "react";
import { Link, useLocation } from "wouter";

export default function SiteLayout({ children }: { children: ReactNode }) {
  const [open, setOpen] = useState(false);
  const [location] = useLocation();
  const links = [["Group", "/group"], ["Businesses", "/group/businesses"], ["Technology", "/technology"], ["Operations", "/operations"], ["Ventures", "/ventures"], ["About", "/about"], ["Contact", "/contact"]];
  useEffect(() => { if (!open) return; const onKeyDown = (event: KeyboardEvent) => { if (event.key === "Escape") setOpen(false); }; window.addEventListener("keydown", onKeyDown); return () => window.removeEventListener("keydown", onKeyDown); }, [open]);
  const isActive = (href: string) => location === href || (href === "/group" && location.startsWith("/group")) || (href === "/group/businesses" && location.startsWith("/group/businesses"));
  return <div className="site-shell"><header className="site-header"><div className="container header-inner"><Link href="/" className="brand" onClick={() => setOpen(false)}><span className="brand-mark">S</span><span>Sanip <em>Ops</em></span></Link><nav id="main-navigation" className={open ? "nav-links open" : "nav-links"} aria-label="Main navigation">{links.map(([label, href]) => <Link key={href} href={href} className={isActive(href) ? "active" : undefined} aria-current={isActive(href) ? "page" : undefined} onClick={() => setOpen(false)}>{label}</Link>)}</nav><div className="header-actions"><Link href="/request" className="text-link desktop-only">Start a project <ArrowUpRight size={15} /></Link><button className="menu-button" onClick={() => setOpen((value) => !value)} aria-expanded={open} aria-controls="main-navigation" aria-label={open ? "Close navigation" : "Open navigation"}>{open ? <X /> : <Menu />}</button></div></div></header><main>{children}</main><Footer /></div>;
}

function Footer() {
  return <footer className="footer"><div className="container footer-grid"><div><Link href="/" className="brand footer-brand"><span className="brand-mark">S</span><span>Sanip <em>Ops</em></span></Link><p className="footer-note">A long-term parent business group building, owning, and operating useful businesses and systems from Nepal.</p></div><div><p className="eyebrow">The group</p><Link href="/group">Group overview</Link><Link href="/group/businesses">Businesses</Link><Link href="/technology">Technology</Link><Link href="/operations">Operations</Link><Link href="/ventures">Ventures</Link></div><div><p className="eyebrow">More</p><Link href="/tools">Tools</Link><Link href="/insights">Insights</Link><Link href="/process">How we work</Link><Link href="/about">About</Link></div><div><p className="eyebrow">Connect</p><Link href="/request">Partner with us</Link><a href="mailto:hello@sanipoperations.com.np">hello@sanipoperations.com.np</a><a href="https://sanipoperations.com.np" target="_blank" rel="noreferrer">sanipoperations.com.np</a></div></div><div className="container footer-bottom"><span>© {new Date().getFullYear()} Sanip Operations</span><span>Nepal · Remote-ready</span></div></footer>;
}
