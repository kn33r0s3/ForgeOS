const trustPoints = [
  ["01", "Clarity", "Plain language, visible scope, and no mystery about what happens next."],
  ["02", "Technical seriousness", "Thoughtful systems that respect constraints, operators, and maintenance."],
  ["03", "Transparent process", "Real work, honestly labelled. No fake stats, testimonials, or client logos."],
] as const;

export default function TrustSection() {
  return <section className="trust-section"><div className="container trust-grid"><div><p className="eyebrow">Trust, without theatre</p><h2>Serious about the<br /><span>work itself.</span></h2></div><div className="trust-list">{trustPoints.map(([number, title, body]) => <article key={number}><span>{number}</span><div><h3>{title}</h3><p className="muted">{body}</p></div></article>)}</div></div></section>;
}
