export default function ValueSection() {
  return <section className="statement"><div className="container statement-grid"><p className="eyebrow">The operating belief</p><h2>Useful technology.<br /><span>Reliable operations.</span><br />Real outcomes.</h2><p className="statement-copy muted">Sanip Ops is being built around a simple standard: use technology where it improves the work, operate with clarity, and measure progress by what becomes possible in the real world.</p></div></section>;
}
