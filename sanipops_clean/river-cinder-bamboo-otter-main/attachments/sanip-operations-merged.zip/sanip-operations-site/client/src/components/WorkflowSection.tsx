import { ArrowRight, ArrowUpRight, Check } from "lucide-react";
import { Link } from "wouter";
import { processSteps } from "./homeData";

export default function WorkflowSection() {
  return <section className="process-section"><div className="container"><div className="section-heading"><div><p className="eyebrow">How we work</p><h2>From unclear to<br /><span>operational.</span></h2></div><Link href="/process" className="text-link">See the process <ArrowUpRight size={15} /></Link></div><div className="process-grid">{processSteps.map((step, index) => <article className="process-card" key={step.number}><div className="process-number">{step.number}</div><div className="process-arrow">{index < processSteps.length - 1 ? <ArrowRight size={18} /> : <Check size={18} />}</div><h3>{step.title}</h3><p className="muted">{step.body}</p></article>)}</div></div></section>;
}
