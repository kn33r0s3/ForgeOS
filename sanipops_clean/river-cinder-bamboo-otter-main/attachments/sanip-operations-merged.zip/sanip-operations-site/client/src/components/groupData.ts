export type GroupArea = { name: string; status: "strategic direction"; description: string };
export type BusinessOffer = { title: string; problem: string; does: string; value: string; start: string };

export const groupAreas: GroupArea[] = [
  { name: "Technology", status: "strategic direction", description: "Systems, infrastructure, and technical foundations that make the wider group more capable." },
  { name: "Digital Products", status: "strategic direction", description: "Useful products and software built around real needs, with room to grow beyond a single project." },
  { name: "Operations", status: "strategic direction", description: "Practical operating systems and disciplined execution across the work the group takes on." },
  { name: "Commerce", status: "strategic direction", description: "Future businesses and commercial activity developed with a clear operating foundation." },
  { name: "Media", status: "strategic direction", description: "Media, content, and communication projects that help useful ideas travel further." },
  { name: "Infrastructure", status: "strategic direction", description: "The underlying platforms and environments that support durable work." },
  { name: "Ventures", status: "strategic direction", description: "A future home for experiments, partnerships, and new businesses when the evidence is right." },
];

export const currentOffers: BusinessOffer[] = [
  { title: "Build digital products", problem: "An idea needs a useful digital surface, but the right first version is unclear.", does: "Shape and build a focused website, web application, internal tool, or product surface around the real user and operating need.", value: "A usable, maintainable first release with a clear scope and an honest next step.", start: "Bring the idea, the intended user, and the job it should make easier." },
  { title: "Develop business software", problem: "Important work is trapped in scattered documents, generic tools, or manual handoffs.", does: "Model the workflow and build the smallest software surface that makes states, decisions, and ownership clearer.", value: "Less ambiguity in daily work and a system that can be improved without starting over.", start: "Share one process that is expensive, slow, or difficult to see." },
  { title: "Automate workflows", problem: "Repeatable digital work consumes time and creates avoidable errors.", does: "Map the current path, identify safe repeatable steps, and connect the relevant tools or actions.", value: "A more consistent workflow with documented boundaries and human control where it matters.", start: "Describe the repeated task, tools involved, and where it currently breaks." },
  { title: "Operate technical systems", problem: "A technical system needs attention, but ownership, context, or the next action is unclear.", does: "Investigate a focused issue, improve the operating routine, and provide practical support within the agreed scope.", value: "Clearer technical ownership, fewer unknowns, and a dependable path to resolution.", start: "Send the symptom, what changed, and what context is available." },
  { title: "Explore a new venture", problem: "A business idea needs technical and operational thinking before significant build-out.", does: "Help test the problem, shape a first operating model, and identify what should be built or learned next.", value: "A grounded decision about whether and how to move forward, without pretending the venture already exists.", start: "Start a strategic inquiry with the idea, uncertainty, and desired outcome." },
];
