export type Service = { number: string; title: string; body: string };
export type ProcessStep = { number: string; title: string; body: string };
export type Capability = { name: string; kind: "prototype" | "commercial" };

export const services: Service[] = [
  { number: "01", title: "Software & web development", body: "Websites, web apps, and focused tools designed around the work they need to support." },
  { number: "02", title: "Business automation", body: "Reduce repeat work with practical automation, integrations, and clearer handoffs." },
  { number: "03", title: "Digital operations", body: "Turn scattered information and recurring tasks into an operating picture people can use." },
  { number: "04", title: "Internal tools", body: "Small, purposeful interfaces for teams, operators, and the decisions they make every day." },
  { number: "05", title: "Workflow systems", body: "Map the path from request to outcome, then make ownership and progress visible." },
  { number: "06", title: "Technical support", body: "Reliable technical thinking and hands-on help when a system needs attention." },
];

export const processSteps: ProcessStep[] = [
  { number: "01", title: "Understand", body: "Start with the real situation, constraints, and the outcome that would make the work better." },
  { number: "02", title: "Build", body: "Shape the smallest useful version, then build in visible steps with clear decisions." },
  { number: "03", title: "Operate", body: "Make the system understandable and usable in the context where the work actually happens." },
  { number: "04", title: "Improve", body: "Learn from use, keep what works, and identify the next sensible improvement." },
];

export const capabilities: Capability[] = [
  { name: "Web applications", kind: "commercial" },
  { name: "APIs & integrations", kind: "commercial" },
  { name: "Automation", kind: "commercial" },
  { name: "Workflow design", kind: "commercial" },
  { name: "Dashboards", kind: "commercial" },
  { name: "Media & data processing", kind: "prototype" },
  { name: "Business systems", kind: "commercial" },
];
