import { ArrowUpRight } from "lucide-react";
import { Link } from "wouter";
import SiteLayout from "@/components/SiteLayout";
import { groupAreas } from "@/components/groupData";

export default function AreaPage({ name }: { name: "Technology" | "Operations" | "Ventures" }) {
  const area = groupAreas.find((item) => item.name === name);
  return <SiteLayout><section className="content-page area-page"><div className="container content-page-inner"><div className="content-page-heading"><p className="eyebrow">Strategic area / {name}</p><h1>{name}<br /><span>is building.</span></h1><p className="lede">{area?.description} This is a long-term direction for Sanip Ops, not a claim that a separate subsidiary or operating company exists today.</p><div className="status-pill">LONG-TERM DIRECTION</div></div><div className="area-detail-panel"><p className="eyebrow">Current status</p><h2>Direction before declaration.</h2><p className="muted">Sanip Ops will only describe a business area as active when there is clear evidence of an operating business behind it. Until then, the work is to learn, build carefully, and keep the distinction visible.</p><Link href="/group/businesses" className="text-link">See what is available today <ArrowUpRight size={15} /></Link></div></div></section></SiteLayout>;
}
