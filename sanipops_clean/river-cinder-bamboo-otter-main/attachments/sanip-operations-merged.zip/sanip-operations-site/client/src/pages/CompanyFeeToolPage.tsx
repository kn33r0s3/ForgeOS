import { FormEvent, useMemo, useState } from "react";
import SiteLayout from "@/components/SiteLayout";
import LeadForm from "@/components/LeadForm";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  calculateRegistrationFee,
  formatNpr,
  MIN_PAID_UP,
  type CompanyType,
} from "@shared/fees";

export default function CompanyFeeToolPage() {
  const [capitalInput, setCapitalInput] = useState("");
  const [companyType, setCompanyType] = useState<CompanyType>("private");

  const result = useMemo(() => {
    const capital = Number(capitalInput.replace(/[^\d.]/g, ""));
    if (!capitalInput || !Number.isFinite(capital) || capital <= 0) return null;
    return calculateRegistrationFee(capital, companyType);
  }, [capitalInput, companyType]);

  return (
    <SiteLayout>
      <section className="detail-hero">
        <div className="container">
          <p className="eyebrow">Tools / Company registration</p>
          <h1>OCR registration<br /><span>fee estimate.</span></h1>
          <p className="lede">
            Estimated fee to register a company with the Office of the Company Registrar
            (OCR) Nepal, by authorized capital. Based on the published schedule under the
            Companies Act 2063, cross-checked across 2025–2026 sources.
          </p>
        </div>
      </section>

      <section className="tools-section">
        <div className="container tool-layout">
          <div>
            <div className="form-wrap">
              <div className="request-form">
                <div>
                  <Label htmlFor="fee_company_type">Company type</Label>
                  <select
                    id="fee_company_type"
                    value={companyType}
                    onChange={(event) => setCompanyType(event.target.value as CompanyType)}
                  >
                    <option value="private">Private Limited</option>
                    <option value="public">Public Limited</option>
                  </select>
                </div>
                <div>
                  <Label htmlFor="fee_capital">Authorized capital (NPR) <span>*</span></Label>
                  <Input
                    id="fee_capital"
                    inputMode="numeric"
                    placeholder="e.g. 1000000"
                    value={capitalInput}
                    onChange={(event) => setCapitalInput(event.target.value)}
                  />
                  {companyType === "private" && (
                    <p className="form-note">Minimum paid-up capital for a Private Limited: {formatNpr(MIN_PAID_UP.private)}.</p>
                  )}
                  {companyType === "public" && (
                    <p className="form-note">Minimum paid-up capital for a Public Limited: {formatNpr(MIN_PAID_UP.public)}.</p>
                  )}
                </div>
              </div>

              {result ? (
                <div className="fee-result" role="status" aria-live="polite">
                  <p className="card-meta"><span>Estimated OCR fee</span><span>{result.slabLabel}</span></p>
                  <p className="fee-figure">{formatNpr(result.registrationFee)}</p>
                  <dl className="fee-lines">
                    <div><dt>Registration fee</dt><dd>{formatNpr(result.registrationFee)}</dd></div>
                    <div><dt>Name reservation</dt><dd>{formatNpr(result.nameReservationFee)}</dd></div>
                    <div className="fee-total"><dt>Estimated total</dt><dd>{formatNpr(result.total)}</dd></div>
                  </dl>
                  <p className="form-note">{result.note}</p>
                </div>
              ) : (
                <p className="muted fee-placeholder">Enter an authorized capital amount to see the estimate.</p>
              )}

              <p className="form-note">
                Estimate only — not an official notice. The OCR portal calculates the exact
                amount at application time. Fees can change with the Finance Act; confirm on{" "}
                <a href="https://camis.ocr.gov.np" target="_blank" rel="noreferrer">camis.ocr.gov.np</a>.
              </p>
            </div>
          </div>

          <aside className="tool-aside">
            <p className="eyebrow">Want help with the process?</p>
            <p className="muted">
              If you would like a registered local firm to walk you through registration,
              leave an inquiry. We share inquiries only with a partner firm that has a real
              agreement with us — never automatically.
            </p>
            <LeadForm
              tool="company-registration-fee"
              contextNote="e.g. Registering a private limited company for a small consultancy"
            />
          </aside>
        </div>
      </section>
    </SiteLayout>
  );
}
