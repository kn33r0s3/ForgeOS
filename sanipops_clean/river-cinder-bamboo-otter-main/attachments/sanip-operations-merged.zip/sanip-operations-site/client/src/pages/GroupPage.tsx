import { ArrowUpRight } from "lucide-react";
import { Link } from "wouter";
import SiteLayout from "@/components/SiteLayout";
import { groupAreas } from "@/components/groupData";

/**
 * The Group — parent-platform overview.
 * Public structure per the Sanip Ops identity: Home · Group · Businesses ·
 * Technology · Operations · Ventures · About · Contact.
 * Honest framing throughout: one parent, real work today, directions tomorrow.
 *
 * NOTE on structure: .status-block / .building-block / .longterm-block are
 * two-child CSS grids (155px marker column + content). Each block below keeps
 * that exact shape: the section itself carries the container width, the marker
 * is the first child, and a single content div is the second.
 */
export default function GroupPage() {
  return (
    <SiteLayout>
      <section className="detail-hero">
        <div className="container">
          <p className="eyebrow">Sanip Operations / The group</p>
          <h1>One parent.<br /><span>Serious directions.</span></h1>
          <p className="lede">
            Sanip Ops is built to eventually own, operate, and scale businesses across
            technology, operations, and ventures — from Nepal, remote-ready. What exists
            today is stated plainly; what is being built and what is long-term are kept
            visibly separate.
          </p>
          <div className="status-pill">ONE UNIFIED PLATFORM</div>
        </div>
      </section>

      <section className="identity-band" aria-hidden="true">
        <div className="container identity-band-inner">
          <span>TECHNOLOGY</span>
          <span>OPERATIONS</span>
          <span>VENTURES</span>
        </div>
      </section>

      <div className="container">
        <section className="status-block">
          <div className="section-marker"><span>TODAY</span><span>01</span></div>
          <div>
            <h2>What is real right now.</h2>
            <p className="muted status-intro">
              A working public platform, honest utility tools, and a live offer of focused
              technical and operational work. Nothing on this page is a claim of
              subsidiaries, revenue, or partnerships.
            </p>
            <div className="offer-grid group-today-grid">
              <article className="offer-card">
                <p className="offer-kicker">LIVE</p>
                <h3>The public platform</h3>
                <p className="muted">This website — services, group structure, and a working project-request flow.</p>
                <Link href="/" className="text-link">Explore the platform <ArrowUpRight size={15} /></Link>
              </article>
              <article className="offer-card">
                <p className="offer-kicker">LIVE</p>
                <h3>Utility tools for Nepali business</h3>
                <p className="muted">An OCR registration-fee calculator and a PAN/VAT guide, built on published schedules with their sources shown.</p>
                <Link href="/tools" className="text-link">Open the tools <ArrowUpRight size={15} /></Link>
              </article>
              <article className="offer-card">
                <p className="offer-kicker">AVAILABLE</p>
                <h3>Technical &amp; operational work</h3>
                <p className="muted">Focused engagements: software, automation, operations, internal tools, workflow systems, support.</p>
                <Link href="/group/businesses" className="text-link">See the current offers <ArrowUpRight size={15} /></Link>
              </article>
            </div>
          </div>
        </section>

        <section className="building-block">
          <div className="section-marker"><span>BUILDING</span><span>02</span></div>
          <div>
            <h2>The operating core.</h2>
            <p className="muted status-intro">
              ForgeOS is in development as Sanip Ops&rsquo; internal, local-first
              intelligence and operations engine: observe, verify, understand, decide, act,
              measure, learn. It grounds the group&rsquo;s decisions in evidence and is not
              sold as a product or connected to this website.
            </p>
            <Link href="/process" className="text-link">How we work <ArrowUpRight size={15} /></Link>
          </div>
        </section>

        <section className="longterm-block">
          <div className="section-marker"><span>LONG-TERM</span><span>03</span></div>
          <div>
            <h2>Directions the group may grow into.</h2>
            <p className="muted status-intro">
              Strategic directions only — not existing subsidiaries, operating companies,
              or revenue. Each becomes a declared business only when there is clear
              evidence of one behind it.
            </p>
            <div className="future-area-grid">
              {groupAreas.map((area) => (
                <div className="future-area" key={area.name}>
                  <strong>{area.name}</strong>
                  <p>{area.description}</p>
                </div>
              ))}
            </div>
          </div>
        </section>
      </div>

      <section className="cta-section">
        <div className="container cta-inner">
          <div>
            <p className="eyebrow">The standard</p>
            <h2>Stated plainly,<br /><span>built to last.</span></h2>
          </div>
          <p className="muted">
            No invented subsidiaries, clients, revenue, investments, awards, partnerships,
            or market share — anywhere on this platform. That rule is the product.
          </p>
        </div>
      </section>
    </SiteLayout>
  );
}
