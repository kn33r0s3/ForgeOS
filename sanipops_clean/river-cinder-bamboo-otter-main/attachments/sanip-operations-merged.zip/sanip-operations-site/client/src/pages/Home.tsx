import SiteLayout from "@/components/SiteLayout";
import Hero from "@/components/Hero";
import ValueSection from "@/components/ValueSection";
import ServicesSection from "@/components/ServicesSection";
import WorkflowSection from "@/components/WorkflowSection";
import CapabilitiesSection from "@/components/CapabilitiesSection";
import ForgeOSSection from "@/components/ForgeOSSection";
import TrustSection from "@/components/TrustSection";
import CTASection from "@/components/CTASection";

export default function Home() {
  return <SiteLayout><Hero /><ValueSection /><ServicesSection /><WorkflowSection /><CapabilitiesSection /><ForgeOSSection /><TrustSection /><CTASection /></SiteLayout>;
}
