import { ArrowUpRight } from "lucide-react";
import SiteLayout from "@/components/SiteLayout";
import { trpc } from "@/lib/trpc";

/**
 * Insights — the content system merged from the Assignment-5 blog/article
 * concept, reimplemented on the single Sanip Ops stack. Content is honest by
 * rule: notes on how we build, never invented clients or revenue.
 */
export default function InsightsPage() {
  const query = trpc.posts.list.useQuery();
  const posts = query.data ?? [];

  return (
    <SiteLayout>
      <section className="detail-hero">
        <div className="container">
          <p className="eyebrow">Sanip Ops / Insights</p>
          <h1>Notes from<br /><span>the build.</span></h1>
          <p className="lede">
            Short, dated notes on how we actually build and operate. No thought-leader
            filler, no invented results.
          </p>
        </div>
      </section>
      <section className="tools-section">
        <div className="container">
          {query.isLoading ? (
            <p className="muted">Loading…</p>
          ) : posts.length === 0 ? (
            <p className="muted">Nothing published yet.</p>
          ) : (
            <div className="content-page-items insights-list">
              {posts.map((post) => (
                <article key={post.slug} className="content-item insight-item">
                  <span>{post.tag}</span>
                  <div>
                    <h2>{post.title}</h2>
                    <p className="muted">{post.excerpt}</p>
                    <p className="insight-body">{post.body}</p>
                  </div>
                </article>
              ))}
            </div>
          )}
          <p className="tool-disclaimer muted">
            Questions about anything here? <a href="/contact" className="text-link">Start a conversation <ArrowUpRight size={14} /></a>
          </p>
        </div>
      </section>
    </SiteLayout>
  );
}
