import SiteLayout from "@/components/SiteLayout";
import LeadForm from "@/components/LeadForm";
import {
  OFFICIAL_PORTALS,
  PAN_VAT,
  REGISTRATION_STEPS,
  REQUIRED_DOCUMENTS,
  formatNpr,
} from "@shared/fees";

export default function PanVatGuidePage() {
  return (
    <SiteLayout>
      <section className="detail-hero">
        <div className="container">
          <p className="eyebrow">Tools / Tax registration</p>
          <h1>PAN &amp; VAT,<br /><span>plainly explained.</span></h1>
          <p className="lede">
            What PAN and VAT registration in Nepal actually costs (nothing), when VAT is
            mandatory, and what the process involves — with links to the official IRD portals.
          </p>
        </div>
      </section>

      <section className="tools-section">
        <div className="container tool-layout">
          <div>
            <div className="fee-result">
              <p className="card-meta"><span>Government fees</span><span>Reference</span></p>
              <dl className="fee-lines">
                <div><dt>PAN registration</dt><dd>{formatNpr(PAN_VAT.panFee)} — free</dd></div>
                <div><dt>VAT registration</dt><dd>{formatNpr(PAN_VAT.vatFee)} — free</dd></div>
                <div><dt>VAT threshold — goods</dt><dd>{formatNpr(PAN_VAT.vatThresholdGoods)} turnover</dd></div>
                <div><dt>VAT threshold — services</dt><dd>{formatNpr(PAN_VAT.vatThresholdServices)} turnover</dd></div>
              </dl>
              <p className="form-note">{PAN_VAT.panNote} {PAN_VAT.vatNote}</p>
            </div>

            <div className="tool-list-block">
              <p className="eyebrow">Registration path</p>
              <div className="content-page-items">
                {REGISTRATION_STEPS.map((step, index) => (
                  <article key={step} className="content-item">
                    <span>{String(index + 1).padStart(2, "0")}</span>
                    <p className="muted">{step}</p>
                  </article>
                ))}
              </div>
            </div>

            <div className="tool-list-block">
              <p className="eyebrow">Typical documents</p>
              <div className="content-page-items">
                {REQUIRED_DOCUMENTS.map((doc) => (
                  <article key={doc} className="content-item">
                    <span>•</span>
                    <p className="muted">{doc}</p>
                  </article>
                ))}
              </div>
            </div>

            <p className="form-note">
              Reference only — not official advice. Confirm current requirements on{" "}
              <a href={OFFICIAL_PORTALS.ird} target="_blank" rel="noreferrer">ird.gov.np</a>.
            </p>
          </div>

          <aside className="tool-aside">
            <p className="eyebrow">Want help with registration?</p>
            <p className="muted">
              Leave an inquiry and we will connect you with a registered local firm that
              handles PAN/VAT registration — only after a real agreement exists, never
              automatically.
            </p>
            <LeadForm tool="pan-vat-guide" contextNote="e.g. Need PAN + VAT registration for a new trading business" />
          </aside>
        </div>
      </section>
    </SiteLayout>
  );
}
