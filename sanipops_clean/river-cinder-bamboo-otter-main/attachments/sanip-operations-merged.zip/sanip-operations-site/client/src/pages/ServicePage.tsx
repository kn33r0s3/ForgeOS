import { ArrowUpRight, Check } from "lucide-react";
import { Link } from "wouter";
import SiteLayout from "@/components/SiteLayout";
import { serviceDetails } from "@/components/businessData";

export default function ServicePage({ slug }: { slug: string }) {
  const service = serviceDetails.find((item) => item.slug === slug) ?? serviceDetails[0];
  const sections = [["The problem", service.problem], ["What Sanip Ops does", service.does], ["What is delivered", service.deliverable], ["How the process works", service.process], ["Who it is for", service.forWho]];
  return <SiteLayout><section className="detail-hero"><div className="container detail-hero-grid"><div><p className="eyebrow">Service / {service.slug}</p><h1>{service.title}</h1><p className="lede">{service.short}</p><Link href="/request" className="primary-button">Start a project <ArrowUpRight size={17} /></Link></div><div className="detail-index"><span>01—06</span><strong>Focused work.<br />Clear ownership.</strong><small>Sanip Operations · Nepal</small></div></div></section><section className="detail-body"><div className="container detail-body-grid"><div className="detail-intro"><p className="eyebrow">A useful scope</p><h2>Good systems begin with the work, not the tool.</h2></div><div className="detail-list">{sections.map(([title, body], index) => <article className="detail-item" key={title}><span>{String(index + 1).padStart(2, "0")}</span><div><h3>{title}</h3><p className="muted">{body}</p></div></article>)}<article className="next-step"><Check size={18} /><div><h3>What happens next</h3><p className="muted">{service.next}</p><Link href="/request" className="text-link">Share the situation <ArrowUpRight size={15} /></Link></div></article></div></div></section></SiteLayout>;
}
