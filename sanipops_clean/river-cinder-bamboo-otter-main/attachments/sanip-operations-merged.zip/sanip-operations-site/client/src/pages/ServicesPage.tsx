import { ArrowUpRight } from "lucide-react";
import { Link } from "wouter";
import SiteLayout from "@/components/SiteLayout";
import { serviceDetails } from "@/components/businessData";

export default function ServicesPage() {
  return <SiteLayout><section className="content-page"><div className="container content-page-inner"><div className="content-page-heading"><p className="eyebrow">Services</p><h1>Useful systems, properly supported.</h1><p className="lede">Focused technical and operational services for work that needs to become clearer, more reliable, or easier to run.</p><Link href="/request" className="primary-button">Start a project <ArrowUpRight size={17} /></Link></div><div className="service-index-list">{serviceDetails.map((service, index) => <Link href={`/services/${service.slug}`} className="service-index-item" key={service.slug}><span>{String(index + 1).padStart(2, "0")}</span><div><h2>{service.title}</h2><p className="muted">{service.short}</p></div><ArrowUpRight size={18} /></Link>)}</div></div></section></SiteLayout>;
}
