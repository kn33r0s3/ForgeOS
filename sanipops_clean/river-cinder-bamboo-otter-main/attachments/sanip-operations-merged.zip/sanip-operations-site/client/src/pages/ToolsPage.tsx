import { ArrowUpRight } from "lucide-react";
import { Link } from "wouter";
import SiteLayout from "@/components/SiteLayout";

const tools = [
  {
    number: "01",
    href: "/tools/company-registration-fee",
    title: "Company registration fee calculator",
    body: "Estimate the OCR registration fee for a Private or Public Limited company in Nepal by authorized capital, based on the published OCR schedule.",
    status: "Estimate only",
  },
  {
    number: "02",
    href: "/tools/pan-vat-guide",
    title: "PAN & VAT guide",
    body: "Registration thresholds, fees (zero), required documents, and the registration path — with links to the official IRD portals.",
    status: "Reference",
  },
];

export default function ToolsPage() {
  return (
    <SiteLayout>
      <section className="detail-hero">
        <div className="container">
          <p className="eyebrow">Sanip Ops / Tools</p>
          <h1>Small, honest<br /><span>utility tools.</span></h1>
          <p className="lede">
            Interactive calculators and references for people registering or formalising a
            business in Nepal. Based on published fee schedules — not scraped rewrites.
            Every tool states its sources and its limits.
          </p>
        </div>
      </section>
      <section className="tools-section">
        <div className="container">
          <div className="tools-grid">
            {tools.map((tool) => (
              <Link key={tool.href} href={tool.href} className="tool-card">
                <div className="card-meta"><span>{tool.number}</span><span>{tool.status}</span></div>
                <h3>{tool.title}</h3>
                <p className="muted">{tool.body}</p>
                <span className="card-link">Open tool <ArrowUpRight size={14} /></span>
              </Link>
            ))}
          </div>
          <p className="tool-disclaimer muted">
            Estimates and references only — not official government notices. Government fees
            can change; always confirm the live amount on{" "}
            <a href="https://camis.ocr.gov.np" target="_blank" rel="noreferrer">camis.ocr.gov.np</a>{" "}
            or <a href="https://ird.gov.np" target="_blank" rel="noreferrer">ird.gov.np</a>.
          </p>
        </div>
      </section>
    </SiteLayout>
  );
}
