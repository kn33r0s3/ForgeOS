CREATE TABLE `project_requests` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(160) NOT NULL,
	`company` varchar(200),
	`email` varchar(320) NOT NULL,
	`phone` varchar(60),
	`projectType` varchar(120) NOT NULL,
	`problem` text NOT NULL,
	`budget` varchar(80),
	`timeline` varchar(80),
	`details` text,
	`status` enum('new','reviewing','contacted','closed') NOT NULL DEFAULT 'new',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `project_requests_id` PRIMARY KEY(`id`)
);
