import { int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export const projectRequests = mysqlTable("project_requests", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 160 }).notNull(),
  company: varchar("company", { length: 200 }),
  email: varchar("email", { length: 320 }).notNull(),
  phone: varchar("phone", { length: 60 }),
  projectType: varchar("projectType", { length: 120 }).notNull(),
  problem: text("problem").notNull(),
  budget: varchar("budget", { length: 80 }),
  timeline: varchar("timeline", { length: 80 }),
  details: text("details"),
  status: mysqlEnum("status", ["new", "reviewing", "contacted", "closed"]).default("new").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

/**
 * Leads from the public utility tools (merged from nepal_utility_portal).
 * Deliberately minimal: no OTPs, PINs, citizenship numbers, or payment
 * credentials are ever collected — inherited house rule from the original
 * lead server.
 */
export const leads = mysqlTable("leads", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 120 }).notNull(),
  phone: varchar("phone", { length: 15 }).notNull(),
  district: varchar("district", { length: 80 }),
  category: varchar("category", { length: 40 }).default("general").notNull(),
  tool: varchar("tool", { length: 80 }),
  note: text("note"),
  status: mysqlEnum("status", ["new", "contacted", "closed"]).default("new").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

/**
 * Public insights/content (merged from the Assignment-5 blog/article system,
 * reimplemented on Drizzle instead of the old MongoDB + Handlebars stack).
 */
export const posts = mysqlTable("posts", {
  id: int("id").autoincrement().primaryKey(),
  slug: varchar("slug", { length: 160 }).notNull().unique(),
  title: varchar("title", { length: 200 }).notNull(),
  excerpt: text("excerpt").notNull(),
  body: text("body").notNull(),
  tag: varchar("tag", { length: 60 }).default("Note").notNull(),
  published: mysqlEnum("published", ["draft", "published"]).default("draft").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type ProjectRequest = typeof projectRequests.$inferSelect;
export type InsertProjectRequest = typeof projectRequests.$inferInsert;
export type Lead = typeof leads.$inferSelect;
export type InsertLead = typeof leads.$inferInsert;
export type Post = typeof posts.$inferSelect;
export type InsertPost = typeof posts.$inferInsert;
