#!/bin/bash
# Sanip Operations ngrok tunnel - http://localhost:3002
# Monitors docker status and keeps tunnel alive

while true; do
  if docker ps --filter "name=sanip-operations-site" --filter "status=running" --quiet | grep -q .; then
    ngrok http 3002 --log=stdout
    sleep 2
  else
    echo "Sanip Operations not running, waiting..."
    sleep 5
  fi
done
