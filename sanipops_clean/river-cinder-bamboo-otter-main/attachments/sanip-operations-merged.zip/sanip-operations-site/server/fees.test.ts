import { describe, expect, it } from "vitest";
import {
  PRIVATE_LIMITED_SLABS,
  PUBLIC_LIMITED_SLABS,
  calculateRegistrationFee,
} from "../shared/fees";

describe("calculateRegistrationFee — merged from nepal_utility_portal", () => {
  it("prices a 1 lakh private company at the lowest slab", () => {
    const r = calculateRegistrationFee(100_000, "private");
    expect(r?.registrationFee).toBe(1_000);
    expect(r?.total).toBe(1_200); // + 200 name reservation
  });

  it("prices mid slabs correctly", () => {
    expect(calculateRegistrationFee(500_000, "private")?.registrationFee).toBe(4_500);
    expect(calculateRegistrationFee(2_500_000, "private")?.registrationFee).toBe(9_500);
    expect(calculateRegistrationFee(10_000_000, "private")?.registrationFee).toBe(16_000);
  });

  it("uses the per-lakh formula above NPR 10 crore for private companies", () => {
    // 10 crore + 1 lakh => 43,000 + 30
    const r = calculateRegistrationFee(100_100_000, "private");
    expect(r?.registrationFee).toBe(43_030);
    expect(r?.slabLabel).toBe("Above NPR 10 crore");
  });

  it("uses the per-crore formula above NPR 50 crore for public companies", () => {
    const r = calculateRegistrationFee(510_000_000, "public");
    expect(r?.registrationFee).toBe(163_000); // 160,000 + 3,000
  });

  it("covers every published slab boundary for both company types", () => {
    expect(PRIVATE_LIMITED_SLABS).toHaveLength(13);
    expect(PUBLIC_LIMITED_SLABS).toHaveLength(6);
    for (const slab of [...PRIVATE_LIMITED_SLABS, ...PUBLIC_LIMITED_SLABS]) {
      expect(slab.fee).toBeGreaterThan(0);
      expect(slab.label).toMatch(/NPR/);
    }
  });

  it("returns null for non-positive or invalid capital", () => {
    expect(calculateRegistrationFee(0, "private")).toBeNull();
    expect(calculateRegistrationFee(-5, "private")).toBeNull();
    expect(calculateRegistrationFee(Number.NaN, "public")).toBeNull();
  });
});
