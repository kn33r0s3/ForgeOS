import { describe, expect, it, vi } from "vitest";
import { appRouter } from "./routers";

vi.mock("./db", () => ({
  createProjectRequest: vi.fn().mockResolvedValue({ id: 1, status: "new" }),
  createLead: vi.fn().mockResolvedValue({ id: 1, status: "new" }),
  listPublishedPosts: vi.fn().mockRejectedValue(new Error("Database is not available")),
}));

const caller = appRouter.createCaller({ user: null, req: {} as never, res: {} as never });

describe("leads.create — merged from nepal_utility_portal lead_server.py", () => {
  it("accepts a valid Nepal mobile and normalizes it to digits", async () => {
    const result = await caller.leads.create({
      name: "Asha Karki",
      phone: "981-234-5678",
      district: "Kathmandu",
      category: "tool-inquiry",
      tool: "company-registration-fee",
    });
    expect(result).toEqual({ success: true });
  });

  it("rejects invalid Nepal mobiles (inherited house rule)", async () => {
    await expect(
      caller.leads.create({ name: "Asha Karki", phone: "12345" }),
    ).rejects.toMatchObject({ code: "BAD_REQUEST" });
    await expect(
      caller.leads.create({ name: "Asha Karki", phone: "981234567" }), // 9 digits
    ).rejects.toMatchObject({ code: "BAD_REQUEST" });
  });

  it("rejects names that are too short", async () => {
    await expect(
      caller.leads.create({ name: "A", phone: "9812345678" }),
    ).rejects.toMatchObject({ code: "BAD_REQUEST" });
  });
});

describe("posts.list — merged content system (Assignment-5 concept)", () => {
  it("falls back to seed content when the database is unavailable", async () => {
    const posts = await caller.posts.list();
    expect(posts.length).toBeGreaterThan(0);
    expect(posts[0]).toHaveProperty("slug");
    expect(posts[0]).toHaveProperty("title");
    expect(posts[0]).toHaveProperty("body");
  });
});
