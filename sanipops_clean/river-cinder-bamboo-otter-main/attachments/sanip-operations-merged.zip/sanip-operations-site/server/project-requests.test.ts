import { describe, expect, it, vi } from "vitest";
import { appRouter } from "./routers";

vi.mock("./db", () => ({
  createProjectRequest: vi.fn().mockResolvedValue({ id: 1, status: "new" }),
}));

describe("projectRequests.create", () => {
  it("accepts a useful request and returns success", async () => {
    const caller = appRouter.createCaller({ user: null, req: {} as never, res: {} as never });
    const result = await caller.projectRequests.create({
      name: "Asha Karki",
      company: "Example Co",
      email: "asha@example.com",
      projectType: "Internal tool",
      problem: "Our team needs a clearer way to track requests and handoffs.",
      timeline: "1–3 months",
    });
    expect(result).toEqual({ success: true });
  });

  it("rejects incomplete problem context", async () => {
    const caller = appRouter.createCaller({ user: null, req: {} as never, res: {} as never });
    await expect(caller.projectRequests.create({
      name: "Asha Karki",
      email: "asha@example.com",
      projectType: "Internal tool",
      problem: "Too short",
    })).rejects.toMatchObject({ code: "BAD_REQUEST" });
  });
});
