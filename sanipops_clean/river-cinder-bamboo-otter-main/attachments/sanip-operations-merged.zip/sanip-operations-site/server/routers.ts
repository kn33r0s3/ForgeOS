import { z } from "zod";
import { TRPCError } from "@trpc/server";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import { createLead, createProjectRequest, listPublishedPosts } from "./db";
import { SEED_POSTS } from "@shared/content";

const projectRequestInput = z.object({
  name: z.string().trim().min(2).max(160),
  company: z.string().trim().max(200).optional(),
  email: z.string().trim().email().max(320),
  phone: z.string().trim().max(60).optional(),
  projectType: z.string().trim().min(2).max(120),
  problem: z.string().trim().min(20).max(6000),
  budget: z.string().trim().max(80).optional(),
  timeline: z.string().trim().max(80).optional(),
  details: z.string().trim().max(2000).optional(),
});

// Minimal in-memory rate limit for the public, unauthenticated project-request
// form — a form anyone on the internet can POST to is a spam/abuse target even
// with strict Zod validation on each field. This caps submissions per IP
// rather than per field content. In-memory is fine for a single-instance
// deploy; if this ever runs behind multiple instances, move the counter to
// the database or a shared cache instead.
const REQUEST_WINDOW_MS = 10 * 60 * 1000; // 10 minutes
const REQUEST_MAX_PER_WINDOW = 5;
const requestLog = new Map<string, number[]>();

function checkRateLimit(ip: string) {
  const now = Date.now();
  const timestamps = (requestLog.get(ip) || []).filter(t => now - t < REQUEST_WINDOW_MS);
  if (timestamps.length >= REQUEST_MAX_PER_WINDOW) {
    throw new TRPCError({
      code: "TOO_MANY_REQUESTS",
      message: "Too many project requests from this connection. Please try again later.",
    });
  }
  timestamps.push(now);
  requestLog.set(ip, timestamps);
  // Bound the map's growth — sweep stale IPs occasionally rather than never.
  if (requestLog.size > 5000) {
    for (const [key, times] of Array.from(requestLog.entries())) {
      if (times.every((t: number) => now - t >= REQUEST_WINDOW_MS)) requestLog.delete(key);
    }
  }
}

// ---------------------------------------------------------------------------
// Leads (merged from nepal_utility_portal lead_server.py, reimplemented on the
// single Sanip Ops backend instead of a second FastAPI service).
//
// House rule inherited from the original: no OTPs, PINs, citizenship numbers,
// or payment credentials are ever accepted. Phone must be a Nepal mobile
// (97/98 followed by 8 digits); it is normalized to digits only before storage.
// ---------------------------------------------------------------------------
const nepalMobile = z
  .string()
  .trim()
  .refine((value) => /^9[78]\d{8}$/.test(value.replace(/\D/g, "")), {
    message: "Phone must be a valid Nepal mobile number (97/98 followed by 8 digits).",
  })
  .transform((value) => value.replace(/\D/g, ""));

const leadInput = z.object({
  name: z.string().trim().min(2).max(120),
  phone: nepalMobile,
  district: z.string().trim().max(80).optional(),
  category: z.string().trim().max(40).default("general"),
  tool: z.string().trim().max(80).optional(),
  note: z.string().trim().max(2000).optional(),
});

// Separate, tighter rate limit for lead intake — phone numbers are personal
// data, so the abuse bar is lower than for project requests.
const LEAD_WINDOW_MS = 30 * 60 * 1000; // 30 minutes
const LEAD_MAX_PER_WINDOW = 3;
const leadLog = new Map<string, number[]>();

function checkLeadRateLimit(ip: string) {
  const now = Date.now();
  const timestamps = (leadLog.get(ip) || []).filter((t) => now - t < LEAD_WINDOW_MS);
  if (timestamps.length >= LEAD_MAX_PER_WINDOW) {
    throw new TRPCError({
      code: "TOO_MANY_REQUESTS",
      message: "Too many inquiries from this connection. Please try again later.",
    });
  }
  timestamps.push(now);
  leadLog.set(ip, timestamps);
  if (leadLog.size > 5000) {
    for (const [key, times] of Array.from(leadLog.entries())) {
      if (times.every((t: number) => now - t >= LEAD_WINDOW_MS)) leadLog.delete(key);
    }
  }
}

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),
  projectRequests: router({
    create: publicProcedure.input(projectRequestInput).mutation(async ({ input, ctx }) => {
      const ip = ctx.req.ip || ctx.req.socket?.remoteAddress || "unknown";
      checkRateLimit(ip);
      await createProjectRequest({ ...input, company: input.company || null, phone: input.phone || null, budget: input.budget || null, timeline: input.timeline || null, details: input.details || null });
      return { success: true } as const;
    }),
  }),
  leads: router({
    create: publicProcedure.input(leadInput).mutation(async ({ input, ctx }) => {
      const ip = ctx.req.ip || ctx.req.socket?.remoteAddress || "unknown";
      checkLeadRateLimit(ip);
      await createLead({
        name: input.name,
        phone: input.phone,
        district: input.district || null,
        category: input.category,
        tool: input.tool || null,
        note: input.note || null,
      });
      return { success: true } as const;
    }),
  }),
  posts: router({
    // Public read of published insights. Falls back to the seed content when
    // no database is configured, so the page renders in every environment.
    list: publicProcedure.query(async () => {
      try {
        const rows = await listPublishedPosts();
        if (rows.length > 0) {
          return rows.map((p) => ({ slug: p.slug, title: p.title, excerpt: p.excerpt, body: p.body, tag: p.tag }));
        }
      } catch {
        // No database — fall through to seed content.
      }
      return SEED_POSTS;
    }),
  }),
});

export type AppRouter = typeof appRouter;
