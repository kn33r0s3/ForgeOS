/**
 * Seed content for the Sanip Ops insights section.
 *
 * The content-system concept (public articles + an editorial workflow) is
 * merged from the Assignment-5 / kr-hosts project, reimplemented on the single
 * Sanip Ops stack. These are fallback/seed posts: the posts table in Drizzle is
 * the source of truth at runtime, and this file is used to seed it and as a
 * read-only fallback when no database is configured.
 *
 * House rule inherited from the originals: no invented clients, revenue, or
 * claims. These are notes on how we actually build.
 */

export type SeedPost = {
  slug: string;
  title: string;
  excerpt: string;
  body: string;
  tag: string;
};

export const SEED_POSTS: SeedPost[] = [
  {
    slug: "evidence-before-claims",
    title: "Evidence before claims",
    excerpt:
      "Why every Sanip Ops statement separates what is observed, inferred, estimated, and unknown.",
    tag: "Operations",
    body:
      "Borrowed from ForgeOS: no claim without provenance. When we say a system works, we point at the measurement. When we estimate, we label it an estimate. When we do not know, we say so. This is not modesty as a pose — it is what makes long-term businesses possible from a small base: decisions compound only when they are grounded. Every capability we publish is labelled prototype or commercial for exactly this reason.",
  },
  {
    slug: "one-system-not-ten-projects",
    title: "One system, not ten projects",
    excerpt:
      "What a decade of building teaches about merging old work instead of rewriting it.",
    tag: "Engineering",
    body:
      "Over years of building — a personal site, hosting dashboards, Discord bots, content platforms, an intelligence engine — the same capabilities get rebuilt: auth, routing, state, content, permissions. The merge rule we now follow: for every capability, find the best idea and the best implementation across everything, then build it once in the canonical platform. Originals stay frozen as reference; nothing weak is preserved just because it is old.",
  },
  {
    slug: "honest-tools-for-nepali-business",
    title: "Honest tools for Nepali business",
    excerpt:
      "Fee calculators and guides that state their sources, their limits, and what they are not.",
    tag: "Products",
    body:
      "Registration fee calculators and PAN/VAT guides are only useful if they are honest. Ours show the published OCR slab schedule, date-stamp the verification, link the official portals, and refuse to guess at anything not in a published schedule. A tool that quietly overstates what it knows costs the user real money. An estimate is a service; a fabricated certainty is a liability.",
  },
];
