/**
 * Nepal company registration fee engine.
 *
 * Merged from the nepal_utility_portal project (data/fees.json + calculator JS),
 * reimplemented as typed, testable TypeScript. Source: Office of the Company
 * Registrar (OCR) Nepal fee schedule, Companies Act 2063 — consistent across
 * multiple 2025-2026 sources. Fees can change with the Finance Act; treat as
 * estimate only and always confirm on camis.ocr.gov.np / ocr.gov.np.
 */

export type FeeSlab = { maxCapital: number; fee: number; label: string };

export const PRIVATE_LIMITED_SLABS: FeeSlab[] = [
  { maxCapital: 100_000, fee: 1_000, label: "Up to NPR 1,00,000" },
  { maxCapital: 500_000, fee: 4_500, label: "NPR 1,00,001 – 5,00,000" },
  { maxCapital: 2_500_000, fee: 9_500, label: "NPR 5,00,001 – 25,00,000" },
  { maxCapital: 10_000_000, fee: 16_000, label: "NPR 25,00,001 – 1,00,00,000" },
  { maxCapital: 20_000_000, fee: 19_000, label: "NPR 1,00,00,001 – 2,00,00,000" },
  { maxCapital: 30_000_000, fee: 22_000, label: "NPR 2,00,00,001 – 3,00,00,000" },
  { maxCapital: 40_000_000, fee: 25_000, label: "NPR 3,00,00,001 – 4,00,00,000" },
  { maxCapital: 50_000_000, fee: 28_000, label: "NPR 4,00,00,001 – 5,00,00,000" },
  { maxCapital: 60_000_000, fee: 31_000, label: "NPR 5,00,00,001 – 6,00,00,000" },
  { maxCapital: 70_000_000, fee: 34_000, label: "NPR 6,00,00,001 – 7,00,00,000" },
  { maxCapital: 80_000_000, fee: 37_000, label: "NPR 7,00,00,001 – 8,00,00,000" },
  { maxCapital: 90_000_000, fee: 40_000, label: "NPR 8,00,00,001 – 9,00,00,000" },
  { maxCapital: 100_000_000, fee: 43_000, label: "NPR 9,00,00,001 – 10,00,00,000" },
];

export const PUBLIC_LIMITED_SLABS: FeeSlab[] = [
  { maxCapital: 10_000_000, fee: 15_000, label: "Up to NPR 1,00,00,000" },
  { maxCapital: 100_000_000, fee: 40_000, label: "NPR 1,00,00,001 – 10,00,00,000" },
  { maxCapital: 200_000_000, fee: 70_000, label: "NPR 10,00,00,001 – 20,00,00,000" },
  { maxCapital: 300_000_000, fee: 100_000, label: "NPR 20,00,00,001 – 30,00,00,000" },
  { maxCapital: 400_000_000, fee: 130_000, label: "NPR 30,00,00,001 – 40,00,00,000" },
  { maxCapital: 500_000_000, fee: 160_000, label: "NPR 40,00,00,001 – 50,00,00,000" },
];

export const NAME_RESERVATION_FEE = 200;
export const MIN_PAID_UP = { private: 100_000, public: 10_000_000 } as const;

export type CompanyType = "private" | "public";

export type FeeBreakdown = {
  companyType: CompanyType;
  capital: number;
  registrationFee: number;
  nameReservationFee: number;
  total: number;
  slabLabel: string;
  note: string;
};

export function calculateRegistrationFee(
  capital: number,
  companyType: CompanyType,
): FeeBreakdown | null {
  if (!Number.isFinite(capital) || capital <= 0) return null;

  const slabs = companyType === "private" ? PRIVATE_LIMITED_SLABS : PUBLIC_LIMITED_SLABS;
  const slab = slabs.find((s) => capital <= s.maxCapital);

  let registrationFee: number;
  let slabLabel: string;
  let note: string;

  if (slab) {
    registrationFee = slab.fee;
    slabLabel = slab.label;
    note = "Slab rate from the OCR published schedule (Companies Act 2063).";
  } else if (companyType === "private") {
    // Above NPR 10 crore: NPR 30 per NPR 1 lakh of authorized capital.
    const excess = capital - 100_000_000;
    const lakhs = Math.ceil(excess / 100_000);
    registrationFee = 43_000 + lakhs * 30;
    slabLabel = "Above NPR 10 crore";
    note = "Above NPR 10 crore: NPR 30 per NPR 1 lakh of authorized capital.";
  } else {
    // Above NPR 50 crore: NPR 3,000 per crore.
    const crores = Math.ceil(capital / 10_000_000);
    registrationFee = 160_000 + (crores - 50) * 3_000;
    slabLabel = "Above NPR 50 crore";
    note = "Above NPR 50 crore: NPR 3,000 per crore of authorized capital.";
  }

  return {
    companyType,
    capital,
    registrationFee,
    nameReservationFee: NAME_RESERVATION_FEE,
    total: registrationFee + NAME_RESERVATION_FEE,
    slabLabel,
    note,
  };
}

export const PAN_VAT = {
  panFee: 0,
  vatFee: 0,
  vatThresholdGoods: 5_000_000,
  vatThresholdServices: 3_000_000,
  panNote: "PAN registration is free via the IRD Taxpayer Portal or Nagarik App.",
  vatNote:
    "No government fee for VAT registration. Mandatory above turnover thresholds (NPR 50 lakh goods / NPR 30 lakh services) or for specified sectors.",
} as const;

export const OFFICIAL_PORTALS = {
  ocr: "https://ocr.gov.np",
  camis: "https://camis.ocr.gov.np",
  ird: "https://ird.gov.np",
} as const;

export const REGISTRATION_STEPS = [
  "Reserve company name on the OCR CAMIS portal (camis.ocr.gov.np)",
  "Prepare Memorandum of Association (MOA) and Articles of Association (AOA)",
  "Create an account and submit the digital application with citizenship / director documents",
  "Pay the OCR registration fee based on authorized capital (the portal calculates the exact amount)",
  "Receive the digital Certificate of Incorporation after OCR review",
  "Register for PAN at IRD within 30 days (free)",
  "Open a company bank account and register for VAT if required by turnover or sector",
];

export const REQUIRED_DOCUMENTS = [
  "Citizenship certificates of directors / promoters",
  "Draft MOA and AOA",
  "Registered office address details (rent agreement or ownership proof)",
  "Passport-size photographs of directors",
  "Digital signatures / biometrics as required by CAMIS",
];

export function formatNpr(amount: number): string {
  return "NPR " + amount.toLocaleString("en-IN");
}
