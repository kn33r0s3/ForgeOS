#!/bin/bash
# Start NGROK for Sanip Operations only
cd /Users/nirojpaudyal/Downloads/sanip-operations-site
exec ngrok http 3002 --log=stdout
