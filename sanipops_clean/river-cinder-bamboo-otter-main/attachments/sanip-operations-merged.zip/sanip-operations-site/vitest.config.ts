import { defineConfig } from "vitest/config";
import path from "path";

const templateRoot = path.resolve(import.meta.dirname);

export default defineConfig({
  root: templateRoot,
  resolve: {
    alias: {
      // zod ships ESM wrappers that re-export from CJS internals; under this
      // environment's bun-based runtime, vitest's module runner loses the
      // named `z` export. Pointing directly at the CJS build fixes it.
      "^zod$": path.resolve(templateRoot, "node_modules/zod/index.cjs"),
      "@": path.resolve(templateRoot, "client", "src"),
      "@shared": path.resolve(templateRoot, "shared"),
      "@assets": path.resolve(templateRoot, "attached_assets"),
    },
  },
  test: {
    environment: "node",
    include: ["server/**/*.test.ts", "server/**/*.spec.ts"],
    server: {
      deps: {
        // Force zod through vite's transform pipeline instead of external
        // native resolution — see the alias note above.
        inline: [/zod/],
      },
    },
  },
});
